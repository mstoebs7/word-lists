"""Word-commonness lookup, used to keep suggestions to words the game accepts.

The bundled dictionary is huge and full of archaic/obscure words (EPURATE,
TUATERA, MARTITE, ...) that casual word games reject. We rank and filter words by
their real English frequency — the Zipf scale from the ``wordfreq`` package, where
roughly:

    ~6-7  extremely common ("the", "put")
    ~4-5  common ("rate", "diameter")
    ~3    still common ("parade", "retired")
    ~2    uncommon
    ~0    essentially not a real everyday word (the junk we want gone)

Frequencies are baked into ``data/words.txt`` at build time, so ``wordfreq`` is only
needed to *build* the dictionary. If a custom word list has no frequencies, we fall
back to a live ``wordfreq`` lookup when it's installed, and otherwise treat the word
as "unknown" (never filtered out, just ranked low).
"""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

try:
    from wordfreq import zipf_frequency as _zipf

    _WORDFREQ_OK = True
except Exception:  # pragma: no cover - optional at runtime
    _WORDFREQ_OK = False


def wordfreq_available() -> bool:
    return _WORDFREQ_OK


@lru_cache(maxsize=200_000)
def zipf(word: str) -> Optional[float]:
    """Zipf frequency (0-8) of ``word`` in English, or None if wordfreq is absent."""
    if not _WORDFREQ_OK:
        return None
    return float(_zipf(word.lower(), "en"))


# Default cut-off. Empirically, >= 3.0 removes the game-rejected junk while keeping
# genuine words like DIAMETER, PARADE, RETREAT, DREAM, MERIT.
DEFAULT_MIN_ZIPF = 3.0
