"""Validate a candidate dictionary against the real game, in practice mode.

The idea: point the solver at a dictionary you're not sure about, then let the autoplay
backend actually *play* its words on the phone and watch what happens. A word whose play
makes the score go up is **accepted** — the game knows it — and gets banked, with the
points it earned, into a growing "tested" dictionary. A word the game ignores is
**rejected** and never tried again. Because longer words are the ones most likely to be
missing from a given game's word list (and the most valuable to confirm), the sweep
prefers the **longest untested word** on each board and works down from there.

This module holds the parts that don't touch a screen — the persistent ledger and the
pure decision logic — so they're fully unit-tested. The CLI (`validate`) drives the
capture/drag loop around them; :mod:`wordlink.calibration` turns the banked
word→score observations into a recalibrated scoring model.
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Dict, List, Optional, Sequence


@dataclass
class WordStat:
    """What we've learned about one accepted word."""

    length: int
    plays: int = 0
    scores: List[int] = field(default_factory=list)   # points earned each accepted play

    def record(self, score: Optional[int]) -> None:
        self.plays += 1
        if score is not None and score > 0:
            self.scores.append(int(score))

    @property
    def best(self) -> Optional[int]:
        return max(self.scores) if self.scores else None

    @property
    def median(self) -> Optional[float]:
        if not self.scores:
            return None
        s = sorted(self.scores)
        n = len(s)
        return float(s[n // 2]) if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2.0


def classify_result(board_changed: bool, score_delta: Optional[int]) -> str:
    """Decide what a played word's outcome was.

    * ``"accepted"`` — the score rose (the word landed and counted), or the board
      refilled with no score reading available (a word was clearly consumed).
    * ``"rejected"`` — the board didn't change and the score didn't rise: the game
      doesn't take this word (or it mis-input — the caller retries once before banking).
    * ``"unknown"`` — can't tell yet (e.g. a transient bad frame); try again.
    """
    if score_delta is not None:
        if score_delta > 0:
            return "accepted"
        # A definite zero-delta with an unchanged board is a rejection.
        return "rejected" if not board_changed else "unknown"
    # No score signal — fall back to whether the board consumed the word.
    if board_changed:
        return "accepted"
    return "rejected"


class WordLedger:
    """Persistent record of which candidate words the game accepts, and their scores.

    Backed by one JSON file. Accepted words carry their observed points (for
    recalibration and for choosing the best-scoring words); rejected words are skipped
    forever. A word is "settled" once it's in either set.
    """

    def __init__(self, path: Optional[str] = None):
        self.path = path
        self.accepted: Dict[str, WordStat] = {}
        self.rejected: set[str] = set()

    # -- recording -----------------------------------------------------------

    def record_accept(self, word: str, score: Optional[int]) -> None:
        word = word.upper()
        self.rejected.discard(word)
        stat = self.accepted.get(word)
        if stat is None:
            stat = WordStat(length=len(word))
            self.accepted[word] = stat
        stat.record(score)

    def record_reject(self, word: str) -> None:
        word = word.upper()
        if word not in self.accepted:      # never un-accept a proven word
            self.rejected.add(word)

    def is_accepted(self, word: str) -> bool:
        return word.upper() in self.accepted

    def is_rejected(self, word: str) -> bool:
        return word.upper() in self.rejected

    def is_settled(self, word: str) -> bool:
        w = word.upper()
        return w in self.accepted or w in self.rejected

    # -- queries -------------------------------------------------------------

    def accepted_words(self) -> List[str]:
        return sorted(self.accepted)

    def observations(self) -> List[tuple]:
        """All ``(word, score)`` observations across accepted words — the input to
        score recalibration."""
        out: List[tuple] = []
        for word, stat in self.accepted.items():
            for sc in stat.scores:
                out.append((word, sc))
        return out

    def coverage_by_length(self) -> Dict[int, Dict[str, int]]:
        """Per length: how many words are accepted vs rejected."""
        cov: Dict[int, Dict[str, int]] = {}
        for w, stat in self.accepted.items():
            cov.setdefault(stat.length, {"accepted": 0, "rejected": 0})["accepted"] += 1
        for w in self.rejected:
            cov.setdefault(len(w), {"accepted": 0, "rejected": 0})["rejected"] += 1
        return dict(sorted(cov.items(), reverse=True))

    # -- persistence ---------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "accepted": {w: asdict(s) for w, s in sorted(self.accepted.items())},
            "rejected": sorted(self.rejected),
        }

    def save(self, path: Optional[str] = None) -> None:
        path = path or self.path
        if not path:
            raise ValueError("No ledger path to save to.")
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2)
            fh.write("\n")

    @classmethod
    def load(cls, path: str) -> "WordLedger":
        led = cls(path=path)
        if path and os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
            for w, s in data.get("accepted", {}).items():
                led.accepted[w.upper()] = WordStat(
                    length=int(s.get("length", len(w))),
                    plays=int(s.get("plays", 0)),
                    scores=[int(x) for x in s.get("scores", [])],
                )
            led.rejected = {w.upper() for w in data.get("rejected", [])}
        return led

    def seed_rejected(self, words) -> int:
        """Merge previously-learned rejected words (e.g. from the shared
        ``rejected_words.txt``) into the ledger. Never overrides a proven word."""
        added = 0
        for w in words:
            w = str(w).strip().upper()
            if w and w.isalpha() and w not in self.accepted and w not in self.rejected:
                self.rejected.add(w)
                added += 1
        return added

    def export_rejected_words(self, path: str) -> int:
        """Write the rejected words as a plain uppercase list (one per line, sorted).

        Deliberately headerless so it stays byte-compatible with the shared
        ``data/rejected_words.txt`` the autoplay loop already reads — the two loops then
        pool what they learn. Returns the number written.
        """
        words = sorted(self.rejected)
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            if words:
                fh.write("\n".join(words) + "\n")
        return len(words)

    def export_tested_dictionary(self, path: str, order: str = "length") -> int:
        """Write the accepted words as a plain word-list usable with ``--dict``.

        One word per line (frequencies are looked up live by the loader). ``order`` is
        ``"length"`` (longest first — matches the validation sweep) or ``"alpha"``.
        Returns the number of words written.
        """
        words = self.accepted_words()
        if order == "length":
            words.sort(key=lambda w: (-len(w), w))
        else:
            words.sort()
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(f"# Tested Word Link dictionary — {len(words)} words the game accepted.\n")
            fh.write("# Auto-generated by `wordlink validate`; scores live in the ledger JSON.\n")
            for w in words:
                fh.write(w + "\n")
        return len(words)


def process_rss_mb() -> Optional[float]:
    """This process's current resident memory in MB, or None if unreadable."""
    try:
        import subprocess
        out = subprocess.run(["ps", "-o", "rss=", "-p", str(os.getpid())],
                             capture_output=True, text=True, timeout=5)
        val = out.stdout.strip()
        if val:
            return int(val) / 1024.0            # ps reports KB
    except Exception:
        pass
    try:
        import resource
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # ru_maxrss is bytes on macOS but KB on Linux.
        return peak / (1024.0 * 1024.0) if sys.platform == "darwin" else peak / 1024.0
    except Exception:
        return None


class MemoryGuard:
    """Trips when the process's resident memory crosses a cap — the safety net that
    turns a would-be overnight swap-storm into a clean stop.

    The validation loop flushes the ledger after every word, so stopping on a trip
    loses nothing: fix/restart and it resumes where it left off. Checks are
    time-throttled (default every 30 s) so calling :meth:`ok` per iteration is free.
    A ``limit_mb`` of 0 disables the guard. Once tripped it stays tripped, with the
    offending reading kept in ``tripped_mb``.
    """

    def __init__(self, limit_mb: float, check_every: float = 30.0, *,
                 rss_fn: Optional[Callable[[], Optional[float]]] = None,
                 clock: Optional[Callable[[], float]] = None):
        self.limit_mb = float(limit_mb)
        self.check_every = float(check_every)
        self._rss_fn = rss_fn or process_rss_mb
        self._clock = clock or time.monotonic
        self._next_check = self._clock()
        self.tripped_mb: Optional[float] = None

    def ok(self) -> bool:
        """True while memory is under the cap; False forever once it wasn't."""
        if self.tripped_mb is not None:
            return False
        if self.limit_mb <= 0:
            return True
        now = self._clock()
        if now < self._next_check:
            return True
        self._next_check = now + self.check_every
        rss = self._rss_fn()
        if rss is not None and rss > self.limit_mb:
            self.tripped_mb = rss
            return False
        return True


def order_candidates(solutions: Sequence, ledger: WordLedger, tried: Optional[set] = None) -> List:
    """Validation ordering: **highest score first**, then longest, skipping words that
    are already settled (accepted/rejected) or tried on this board.

    Score-first means we discover and bank the biggest-scoring words earliest — which is
    the whole point of building a dictionary of the highest-scoring words.
    """
    tried = tried or set()

    def key(s):
        return (s.score, len(s.word))

    out = [s for s in solutions if not ledger.is_settled(s.word) and s.word not in tried]
    out.sort(key=key, reverse=True)
    return out


def next_candidate(solutions: Sequence, ledger: WordLedger, tried: Optional[set] = None):
    """The single best word to try next under the validation ordering, or None."""
    ordered = order_candidates(solutions, ledger, tried)
    return ordered[0] if ordered else None


def best_accepted(solutions: Sequence, ledger: WordLedger, exclude: Optional[set] = None):
    """The **highest-scoring** already-accepted word on the board (ties → longest),
    skipping any in ``exclude``. This is the known word we replay to keep racking score
    and cycling in fresh letters when there's nothing new to test. Returns None if no
    accepted word is available."""
    exclude = exclude or set()
    cands = [s for s in solutions if ledger.is_accepted(s.word) and s.word not in exclude]
    return max(cands, key=lambda s: (s.score, len(s.word))) if cands else None


def plan_turn(solutions: Sequence, ledger: WordLedger, churn_tried: Optional[set] = None):
    """Decide the next move for the validation loop — the pure heart of "rip words for
    score while validating", kept out of the hardware loop so it's fully testable.

    Returns ``(action, solution)``:

    * ``("test", s)``  — play a NEW word to validate it (and score). Preferred: this is
      how the dictionary grows. ``s`` is the highest-scoring untested word.
    * ``("churn", s)`` — no new word here, so REPLAY the **highest-scoring** accepted
      word to keep the score climbing and cycle in fresh letters. ``s`` skips anything in
      ``churn_tried`` (accepted words that just mis-dragged on this board, to rotate past
      a bad drag rather than spin).
    * ``("wait", None)`` — no untested word and no accepted word can be played here (every
      known word already mis-dragged this board, or none is spellable). The caller waits
      *silently* for a fresh board — no message.
    """
    cand = next_candidate(solutions, ledger)
    if cand is not None:
        return ("test", cand)
    churn = best_accepted(solutions, ledger, churn_tried)
    if churn is not None:
        return ("churn", churn)
    return ("wait", None)
