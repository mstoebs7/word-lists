"""Build ``data/words.txt`` from a source word list, annotated with word frequency.

Each output line is ``WORD ZIPF`` — the word plus its English Zipf frequency (from
the ``wordfreq`` package), e.g. ``PUT 5.66``. The frequency is used only for the
optional ``--min-freq`` filter and the "common" sort; ranking is by the game's real
score.

**Source.** By default it reads the bundled ``data/enable.txt`` — the ENABLE word
list (~173k words), the standard, simpler English dictionary most Boggle/word-game
solvers use. It has broad coverage without the mass of obscure words in the larger
Collins list, so fewer suggestions get rejected. (``data/sowpods.txt``, the ~267k
Collins/SOWPODS list, is also bundled — pass ``--source data/sowpods.txt`` to
maximise coverage instead.) A small supplement adds informal / modern short words
these lists lack (OK, IE, EW, QI, ZA, ...).

Words that aren't fully lowercase in the source are skipped (drops proper nouns and
acronyms from a system dictionary; a no-op for ENABLE). Words below ``--floor`` Zipf
are dropped; the default floor is 0 so genuine low-frequency game words (QI, ZA, XU)
survive.

Usage:
    python -m wordlink.build_dictionary
    python -m wordlink.build_dictionary --source /path/to/wordlist.txt --floor 0
"""

from __future__ import annotations

import argparse
import os
import sys

_HERE = os.path.dirname(__file__)
_DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
_DEFAULT_OUT = os.path.join(_DATA, "words.txt")
_BUNDLED_SOWPODS = os.path.join(_DATA, "sowpods.txt")
_BUNDLED_ENABLE = os.path.join(_DATA, "enable.txt")
_SYSTEM_WORDS = "/usr/share/dict/words"

# Words the game accepts that the ENABLE list omits. Two groups:
#   * informal words confirmed from score cards (OK, IE, EW);
#   * standard modern word-game 2-letter words that predate-2000 ENABLE lacks but
#     every current word game accepts (QI, ZA, ... — several use the 4-point
#     letters Q/Z/K, making them premium high-value plays).
# Add more here whenever you see the game accept a word we don't list.
INFORMAL_SUPPLEMENT = [
    "OK", "IE", "EW",
    "DA", "FE", "FY", "GI", "IO", "KI", "KO", "KY", "NY", "OB", "OI", "OO",
    "OU", "PO", "QI", "ST", "TE", "UG", "UR", "YU", "ZA", "ZO",
]


def _default_source() -> str:
    # ENABLE is the standard, simpler English word-game list — fewer obscure words
    # get rejected than with the larger Collins/SOWPODS. (Use --source data/sowpods.txt
    # to rebuild from the comprehensive list instead.)
    for candidate in (_BUNDLED_ENABLE, _BUNDLED_SOWPODS):
        if os.path.exists(candidate):
            return candidate
    return _SYSTEM_WORDS


def build(source: str, out: str, min_length: int, max_length: int, floor: float) -> int:
    if not os.path.exists(source):
        raise FileNotFoundError(f"Source word list not found: {source}")

    try:
        from wordfreq import zipf_frequency
    except Exception as exc:  # pragma: no cover
        raise SystemExit(
            "wordfreq is required to build the dictionary. Install it with:\n"
            "    pip install wordfreq\n"
            f"(import failed: {exc})"
        )

    seen: set[str] = set()
    rows: list[tuple[str, float]] = []

    def consider(word_lower: str, force: bool = False) -> None:
        w = word_lower.upper()
        if not (min_length <= len(w) <= max_length) or w in seen:
            return
        z = float(zipf_frequency(word_lower, "en"))
        if z < floor and not force:  # `force` keeps supplement words regardless
            return
        seen.add(w)
        rows.append((w, z))

    with open(source, "r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            orig = line.strip()
            # Drop proper nouns (Title-cased in a mixed-case system dictionary, e.g.
            # "Aaron", "Paris"). Works for word-game lists too: SOWPODS is all-upper
            # and ENABLE all-lower, neither is Title-cased, so nothing is lost.
            if not orig.isalpha() or orig.istitle():
                continue
            consider(orig.lower())

    # The supplement (OK, IE, QI, ZA, ...) is always kept, even below the floor —
    # these are confirmed/premium game words that happen to be low-frequency.
    for extra in INFORMAL_SUPPLEMENT:
        consider(extra.lower(), force=True)

    rows.sort(key=lambda r: r[0])
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        for w, z in rows:
            fh.write(f"{w} {z:.2f}\n")
    return len(rows)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Build the wordlink dictionary file.")
    p.add_argument("--source", default=None, help="Source word list (default: bundled ENABLE).")
    p.add_argument("--out", default=_DEFAULT_OUT, help="Output words.txt path.")
    p.add_argument("--min-length", type=int, default=2)
    p.add_argument("--max-length", type=int, default=16)
    p.add_argument(
        "--floor",
        type=float,
        default=2.5,
        help="Keep only words at or above this Zipf frequency (default 2.5 = common, "
        "'usual' English words; the supplement is always kept). Use 0 for the full list.",
    )
    args = p.parse_args(argv)

    source = args.source or _default_source()
    count = build(source, args.out, args.min_length, args.max_length, args.floor)
    print(f"Wrote {count:,} words (with frequencies) to {args.out}\n  source: {source}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
