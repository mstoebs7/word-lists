# Word Link dictionary validation data

Results from testing which words a 4×4 Word Link–style mobile game accepts. Words
were played automatically in practice mode between Jul 10 and Jul 17, 2026. A word was
recorded as **accepted** if the game took it and scored it, and **rejected** if it didn't.

**Headline numbers:** 5,939 words tested: 3,796 accepted (4,343 plays) and 2,143 rejected.
All candidates came from the ENABLE word list.

## Start here

| File | What it is |
|---|---|
| `word_results.csv` | **The main file.** One row per tested word: `word, status, length, zipf, plays, best_score, mean_score, all_scores, in_common_list, note`. |
| `accepted_words.txt` | Accepted words, one per line, A–Z. |
| `rejected_words.txt` | Rejected words, one per line, A–Z (cleaned; see "Data quality" below). |
| `summary_by_zipf.csv` | Accept rate by Zipf frequency bucket. |
| `summary_by_length.csv` | Accept rate by word length. |

## Word lists

| File | What it is |
|---|---|
| `word_lists/enable.txt` | The source list: ENABLE, 172,823 words (public domain). Every tested word came from here. |
| `word_lists/enable_with_zipf_and_status.csv` | All of ENABLE with `length, zipf, in_common_list, status` (accepted / rejected / **untested**). 166,884 words were never tried. |
| `word_lists/common_words_zipf2.5.txt` | The "common" list used by default: ENABLE filtered to Zipf ≥ 2.5, plus 25 short words ENABLE lacks (OK, IE, EW, QI, ZA…). Format: `WORD ZIPF`. |

## Originals (untouched copies)

| File | What it is |
|---|---|
| `original_data/validation.json` | The raw ledger: `{"accepted": {WORD: {length, plays, scores[]}}, "rejected": [WORD, ...]}`. |
| `original_data/rejected_words.txt` | The live reject list as it stood, with 27 stale entries (see below). |
| `original_data/tested_words.txt` | An older export of accepted words (Jul 14, 3,589 words). Superseded by `accepted_words.txt`. |
| `original_data/scoring_profile.json` | Score model fitted from 75 observed plays: per-letter values and length multipliers. |
| `raw_logs/autoplay/*.jsonl` | The only two early sessions with per-word logs (202 attempts, Jul 10): `word, expected, score_before, score_after, delta, success`. |
| `code/` | The scripts behind the data: `build_dictionary.py` (builds the common list), `frequency.py` (Zipf lookup), `validation.py` (the ledger). |

## About the Zipf score

`zipf` comes from the [`wordfreq`](https://pypi.org/project/wordfreq/) Python package
(v3.1.1): `zipf_frequency(word.lower(), "en")`. It's log-scaled: about 6–7 is
extremely common ("the"), 4–5 is common, 3 is still familiar, 2 is uncommon, and 0
means effectively unseen in everyday English. All values here were computed fresh
with that version.

## What the data says

The game's dictionary looks like a **common-English subset of ENABLE**, not a full
tournament list. How common a word is predicts acceptance well:

| Zipf | Accepted | Rejected | Accept rate |
|---|---|---|---|
| 0 – 1 | 207 | 1,113 | 16% |
| 1 – 2 | 402 | 639 | 39% |
| 2 – 2.5 | 331 | 196 | 63% |
| 2.5 – 3 | 773 | 89 | 90% |
| 3 – 3.5 | 737 | 49 | 94% |
| 3.5 – 4 | 524 | 29 | 95% |
| 4 – 5 | 619 | 22 | 97% |
| 5+ | 203 | 6 | 97% |

Still, rarity alone doesn't get a word rejected: 207 near-zero-frequency words were
accepted (GEWGAW, MINUEND, LAMBENCY, WRYEST…). Word types the game seems to reject:

- **Obscure ENABLE words:** DAEDAL, EIRENIC, TUTOYER, TOKONOMA, SHEUCH.
- **Words that look like proper nouns:** TEXAS, HENRY, DEVON, CONGO, TOLEDO, OTTO, DONNA.
- **Some interjections:** HMM, HAHA, YAH (though HA and HM were accepted).

**Not tested:** words in Collins/SOWPODS but not in ENABLE were never tried, so this
data can't say whether the game accepts them.

## Data quality: read before relying on it

These issues come from the automation, not the game. They're flagged in the `note`
column of `word_results.csv`, and nothing was deleted:

1. **Possible false rejects (57 words).** Rejected words with Zipf ≥ 3.5 carry the
   note *"common word rejected - possibly a false reject"*. Some are probably real
   rejections (proper-noun-like words such as TEXAS and HENRY). Others almost
   certainly aren't: **MY, YOUR, MAY, WHY, LOVE, CREATE, TRULY, PITCH, TOXIC,
   PANIC, COPPER…** For example, WHY was rejected while WHO and HOW were accepted.
   Early on, one missed swipe was enough to blacklist a word, and the board reading
   was unreliable. Later versions required two misses in a row.
2. **Possible phantom accepts (33 words).** Accepted words of 5+ letters whose best
   score was under 200 are flagged *"low score - possibly a phantom accept"*. The game's
   score animates for about half a second, so the tail of the previous word's points
   could be credited to a word that was actually refused. The project notes name
   SODALITY (+67) and BORTY as phantom accepts, and separately call UNROOT a rejected
   word, but all three are in the accepted ledger. Others to treat with suspicion
   include ANGELUS, BEWEARY, KNOCKER, TOOTSY, ROWEN, ORFRAY and ALDEHYDE.
3. **Stale reject entries (27 words).** `original_data/rejected_words.txt` still
   lists 27 words that were later accepted (COURT, FORCE, TOTAL, FLOOD, URGENT…).
   Accepted wins, so they're removed from the cleaned `rejected_words.txt` and
   noted in the CSV.
4. **Missing scores.** 100 accepted words have no recorded score (the reading failed).
   Their `best_score` is blank.
5. **Scores vary by board.** Tile values change from board to board, so the same word
   can score differently (ACETATE scored 771 and 806). Treat scores as samples, not
   fixed values.
